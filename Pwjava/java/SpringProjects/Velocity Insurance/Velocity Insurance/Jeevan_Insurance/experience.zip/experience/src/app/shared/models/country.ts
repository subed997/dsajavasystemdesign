export class Country {
    constructor(public name: string) { }
  }
