export class State {
    constructor(public country: string, public name: string) { }
  }
