export class Policy {

    public id:number;
    public policyNumber:string;
	public premiumAmount:string;
	public email:string;
	public name:string;
    public claimNumber:string;
    public status:string;

}
