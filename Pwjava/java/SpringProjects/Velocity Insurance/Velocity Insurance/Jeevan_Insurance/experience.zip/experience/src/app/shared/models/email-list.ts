export class EmailList{
    public name:string;
    public selector:boolean;
    constructor(){

    }
}